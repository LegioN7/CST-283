module com.example.quadfungui {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.controlsfx.controls;
    requires net.synedra.validatorfx;

    opens com.example.quadfungui to javafx.fxml;
    exports com.example.quadfungui;
}