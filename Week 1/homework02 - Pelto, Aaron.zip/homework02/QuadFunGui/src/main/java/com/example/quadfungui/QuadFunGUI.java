package com.example.quadfungui;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class QuadFunGUI extends Application {
    // Declare objects
    private TextField aField;
    private TextField bField;
    private TextField cField;
    private TextField xField;
    private Label funFormLabel;
    private Label aLabel;
    private Label bLabel;
    private Label cLabel;
    private Label xValueLabel;
    private Label functionLabel;
    private Button calcYbutton;
    private Button clearButton;

    public static void main(String[] args) {
        // Launch the application.
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        // Initialize label objects
        funFormLabel = new Label("Function:  y = ax^2 + bx + c");

        // Define and organize function input fields
        aLabel = new Label("a");
        aField = new TextField();
        bLabel = new Label("b");
        bField = new TextField();
        cLabel = new Label("c");
        cField = new TextField();
        HBox aBox = new HBox(10, aLabel, aField);
        HBox bBox = new HBox(10, bLabel, bField);
        HBox cBox = new HBox(10, cLabel, cField);
        HBox funBox = new HBox(30, aBox, bBox, cBox);
        funBox.setAlignment(Pos.CENTER);

        // Define and organize x input fields
        xValueLabel = new Label("x");
        xField = new TextField();
        HBox xValueBox = new HBox(10, xValueLabel, xField);
        xValueBox.setAlignment(Pos.CENTER);

        // Define calculate button and register button event handler
        calcYbutton = new Button("Calculate");
        calcYbutton.setOnAction(new ConvertButtonClickHandler());

        // Define "clear" button and locally define action.
        clearButton = new Button("Clear");
        clearButton.setOnAction(event ->
        {
            aField.setText("");
            bField.setText("");
            cField.setText("");
            xField.setText("");
        });

        // Combine buttons in horizontal box.
        HBox buttonBox = new HBox(10, calcYbutton, clearButton);
        buttonBox.setAlignment(Pos.CENTER);

        // Set up function and y labels - will be "set" via button event listener
        functionLabel = new Label();
        HBox functionBox = new HBox(functionLabel);
        functionBox.setAlignment(Pos.CENTER);

        // Combine all horizontal rows of interface components in a primary vertical box.
        VBox mainBox = new VBox(10, funFormLabel, funBox, xValueBox, functionLabel, buttonBox);
        mainBox.setAlignment(Pos.CENTER);

        // Set up overall scene
        Scene scene = new Scene(mainBox, 500, 300);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Quadratic Function Calculator");
        primaryStage.show();
    }

    // Handle "Calculate" button click event.
    class ConvertButtonClickHandler implements EventHandler<ActionEvent> {
        @Override
        public void handle(ActionEvent event) {
            double aValue = 0;
            double bValue = 0;
            double cValue = 0;
            double xValue = 0;
            double zValue = 0;
            double yValue = 0;

            // Get inputs from text fields
            String aVariable = aField.getText();
            String bVariable = bField.getText();
            String cVariable = cField.getText();
            String xVariable = xField.getText();

            boolean inputOK = true;

            // Parse inputs and perform input number format check
            try {
                aValue = Double.parseDouble(aVariable);
                bValue = Double.parseDouble(bVariable);
                cValue = Double.parseDouble(cVariable);
                xValue = Double.parseDouble(xVariable);
            } catch (NumberFormatException e) {
                inputOK = false;
            }

            // Perform calculations.  Set values in fields.
            if (inputOK) {
                zValue = Math.pow(aValue, xValue);
                yValue = (zValue + (bValue * xValue) + cValue);
                functionLabel.setText(yValue + " = " + "(" + aValue + "^" + xValue + ")" + " " + "+" + " " + "(" + bValue + "*" + xValue + ")" + " " + "+" + " " + cValue);
            } else   // If any errors,
            {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Input Error.");
                alert.setContentText("Please check input values.");
                alert.showAndWait();
            }
        }
    }
}